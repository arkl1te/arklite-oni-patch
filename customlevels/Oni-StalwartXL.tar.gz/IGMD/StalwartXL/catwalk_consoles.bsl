# Added by Catwalk: the messages of consoles (ActivationMessage).

func void cw_message_116(string ai_name)
{
	text_console cw_message_116
}

