# StalwartXL: level scripts. Oni runs main() when the level starts.

func void main(void)
{
	# Added by Catwalk: particles placed to run from the start.
	particle autostart do start

	# Added by Catwalk: the level's music.
	sound_music_start mus_pursuit 0.35

	gs_farclipplane_set 5000
}
